echo "LC_ALL=en_US.UTF-8" > /etc/environment
echo "LANG=en_US.UTF-8" >> /etc/environment